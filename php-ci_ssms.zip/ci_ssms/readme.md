### Simple Sales Management System in PHP using CodeIgniter 3 Framework
==========================================================

### Recommended PHP Version
- PHP >= 7.4

==========================================================
### **Developement Information**
==========================================================
#### ** Original Version**
- **Developed/Published By:** Olaiya Segun Paul
- **Uploaded/Published at:** [https://codeastro.com/simple-inventory-management-system-in-php-codeigniter-with-source-code/](https://codeastro.com/simple-inventory-management-system-in-php-codeigniter-with-source-code/) 
==========================================================
#### ** Upgraded/Customization Version**
- **Upgraded and Modified By:** oretnom23
- **Published at:** [https://sourcecodester.com/php-codeigniter-simple-sales-management-system-source-code](https://sourcecodester.com/php-codeigniter-simple-sales-management-system-source-code) 

#### **Modification Information**
- upgraded the CodeIgniter Core System to CI_VERSION == 3.1.13
- Customize some of the User Interface (CSS)
- Modified Some features
==========================================================
### **Disclaimer**
- No copyright intended.
- Credit to the Original Developer
- Customized and Modified only for Educational Purposes
==========================================================

==========================================================
### **Admin Access**
- **Email:** admin@mail.com
- **Password:** admin123
==========================================================